﻿# -*- coding: utf-8 -*-
import urllib, urllib2, sys, xbmcplugin ,xbmcgui, xbmcaddon, xbmc, os, platform, json, re, time, hashlib
import cookielib


AddonID = 'plugin.video.tvVietnam'
__settings__ = xbmcaddon.Addon(id='plugin.video.tvVietnam')
Addon = xbmcaddon.Addon(AddonID)
localizedString = Addon.getLocalizedString
AddonName = Addon.getAddonInfo("name")
icon = Addon.getAddonInfo('icon')

addonDir = Addon.getAddonInfo('path').decode("utf-8")

libDir = os.path.join(addonDir, 'resources', 'lib')
sys.path.insert(0, libDir)
import common

addon_data_dir = os.path.join(xbmc.translatePath("special://userdata/addon_data" ).decode("utf-8"), AddonID)
if not os.path.exists(addon_data_dir):
	os.makedirs(addon_data_dir)
	

isRasp = False	

try:
	if ("Linux-4.1.9-v7" in platform.platform()):
		isRasp = True
except:
	isRasp = False	
#Linux
#4.1.9-v7+
	

playlistsFile = os.path.join(addon_data_dir, "playLists.txt")
tmpListFile = os.path.join(addon_data_dir, 'tempList.txt')
htvListFile = os.path.join(addon_data_dir, 'htvList.txt')
favoritesFile = os.path.join(addon_data_dir, 'favorites.txt')
htvFile = os.path.join(addon_data_dir, 'htv.m3u')
fptFile = os.path.join(addon_data_dir, 'fpt.m3u')
vietFile = os.path.join(addon_data_dir, 'viet.m3u')

if  not (os.path.isfile(favoritesFile)):
	f = open(favoritesFile, 'w') 
	f.write('[]') 
	f.close() 

cookie_filename = os.path.join(addon_data_dir, "cookie.txt")
cookieJar = cookielib.MozillaCookieJar(cookie_filename)
if os.access(cookie_filename, os.F_OK):
	cookieJar.load(ignore_discard=True)
	
	
htv_filename = os.path.join(addon_data_dir, "htvcookie.txt")
htvCookieJar = cookielib.MozillaCookieJar(htv_filename)
if os.access(htv_filename, os.F_OK):
	htvCookieJar.load(ignore_discard=True)	



def getXemTvHd(url):
	headers = {
    'Host': 'm.xemtvhd.com',
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:39.0) Gecko/20100101 Firefox/39.0',
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
    'Accept-Language': 'en-US,en;q=0.5',
    'Connection': 'keep-alive',
		}
 
	myreq= urllib2.Request(url,headers=headers)
	response = urllib2.urlopen(myreq)
	result=response.read()
	nextUrl = re.compile('iframe\s*src=\s*\"([^\"]*)\"').findall(result)[0]
	
	headers = {
    'Host': 'm.xemtvhd.com',
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:39.0) Gecko/20100101 Firefox/39.0',
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
    'Accept-Language': 'en-US,en;q=0.5',
    'Referer': url,
    'Connection': 'keep-alive',
		}
     
	myreq= urllib2.Request(nextUrl,headers=headers)
	response = urllib2.urlopen(myreq)
	result=response.read()
	finalUrl = re.compile('stream\s*=\s*\'([^\']*)\'').findall(result)[0]

	return finalUrl



def getTHVL(url):
	vIndex = url.index("//",7)
	vIndex = vIndex + 2
	titleName = url[vIndex :]
		
	vLink = "http://www.thvl.vn/jwplayer/jw_backup1.php?"
	if 'rtmp2' in url:
		vLink = "http://thvl.vn/jwplayer/jw_backup1.php?"
		
	newUrl = vLink + titleName
	refLink = "http://www.thvl.vn/jwplayer/?"
	refUrl = refLink + titleName;

	headers = {
		'Host': 'thvl.vn',
		'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:39.0) Gecko/20100101 Firefox/39.0',
		'Accept': '*/*',
		'Accept-Language': 'en-US,en;q=0.5',
    'Connection': 'keep-alive',
    'Referer': refUrl,
		}

	 
	myreq= urllib2.Request(newUrl,headers=headers)
	response = urllib2.urlopen(myreq)
	result=response.read()
	finalUrl = re.compile('file:\s*\"([^\"]*)\"').findall(result)[0]
	
	return finalUrl



	
		
def getHTV(url):
	

	opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(htvCookieJar))

	headers = {
		'Host': 'hplus.com.vn',
		'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:39.0) Gecko/20100101 Firefox/39.0',
		'Accept': '*/*',
		'Accept-Language': 'en-US,en;q=0.5',
		'Referer': 'http://hplus.com.vn/vi/categories/live-tv'
		}

	myreq= urllib2.Request(url,headers=headers)

	isoUrl = None
	finalUrl = None
	
	try:
		conn = opener.open(myreq)
		headers = conn.info()
		#print "status code: ", conn.getcode()
		if ("Set-Cookie" in headers):
			htvCookieJar.save(ignore_discard=True)
			print "========================================Save Cookie"
			print "=====headers ", headers
		
		content = conn.read()
		isoUrl = re.compile('iosUrl\s*=\s*\"([^\"]*)\"').findall(content)[0]
		conn.close()
		
	except:
		print "===========Fail to get HTV Response"
		return finalUrl
		
	
	
	
	try:
		time.sleep(0.1)
		myurl = 'http://hplus.com.vn/content/getlinkvideo'	

		headers = {
			'Host': 'hplus.com.vn',
			'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:39.0) Gecko/20100101 Firefox/39.0',
			'Accept': '*/*',
			'Accept-Language': 'en-US,en;q=0.5',
			'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
			'X-Requested-With': 'XMLHttpRequest',
			'Referer': 'http://hplus.com.vn/vi/categories/live-tv',
			'Connection': 'keep-alive',
			'Pragma': 'no-cache',
			'Cache-Control': 'no-cache'
			}
			
		params = {"url": isoUrl,"type": "1"}
		mydata = urllib.urlencode(params)
		myreq= urllib2.Request(myurl, mydata, headers)
		conn = opener.open(myreq)
		finalUrl = conn.read()
		print "====finalUrl " + finalUrl 
		conn.close()
		
	except:
		print "===========Fail to get HTV Response round 2"
		return finalUrl
	
	
	return finalUrl

def logintoSCTV():
	opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(cookieJar))
	myurl = 'http://tv24.vn/account/login'
	headers = {
			'Host': 'tv24.vn',
    			'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:41.0) Gecko/20100101 Firefox/41.0',
    			'Accept': '*/*',
    			'Accept-Language': 'en-US,en;q=0.5',
    			'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
    			'X-Requested-With': 'XMLHttpRequest',
    			'Referer': 'http://tv24.vn/'
		   }
	params = {'email': __settings__.getSetting('userID'),'password':__settings__.getSetting('password')}
	mydata = urllib.urlencode(params)

	myreq= urllib2.Request(myurl, mydata, headers)
	#response = urllib2.urlopen(myreq)
	#the_page = response.read()
	
	try:
		conn = opener.open(myreq)
		cookieJar.save(ignore_discard=True)
		connRead = conn.read()
		print "==================================logintoSCTV Response " + connRead 
		headers = conn.info()
		print "The Headers are: ", headers 
		print "===========Header " + headers.getheader('Set-Cookie')
		conn.close()
		
	except:
		print "===========Fail to get cookie"
		pass


def getSCTV(url):
    opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(cookieJar))
    #urllib2.install_opener(opener)
    txdata = None  
    txheaders =  {
    			'Host': 'tv24.vn',
    			'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:39.0) Gecko/20100101 Firefox/39.0',
    			'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
    			'Accept-Language': 'en-US,en;q=0.5',
    			'Connection': 'keep-alive',
	}
	


    myreq = urllib2.Request(url, txdata,txheaders)    # create a request object
    #response = urllib2.urlopen(myreq)                       # and open it to return a handle on the url
    #content = response.read()
    conn = opener.open(myreq)
    content = conn.read()

    newUrl = None

    try:
        newUrl = re.compile('file:\s*\"([^\"]*)\"').findall(content)[0]

    except:
        print "===========Fail to get URL"
        pass

    print "======New URL ", newUrl

    return newUrl


def getSCTVWithCookie(url):

    newUrl = getSCTV(url)

    if (newUrl == None) or ('khongduocxoa' in newUrl):
        logintoSCTV()
	newUrl = getSCTV(url)

    return newUrl


def home():
    apilink = "http://api.htvonline.com.vn/tv_channels"
    reqdata = '{"pageCount":200,"category_id":"-1","startIndex":0}'
    data = getContent ( apilink , reqdata)
#    f = open(htvFile, "w")
#    f.write("#EXTM3U\n")
#    f2 = open(vietFile, "w")
#    f2.write("#EXTM3U\n")

    htvList = []
    for d in data ["data"] :
        res = d["link_play"][0]["resolution"]
        img = d["image"]
        title = d["name"]+' ('+res+')'
        link = d["link_play"][0]["mp3u8_link"]
	unicodestr = title.encode('utf-8').strip()
#	f.write("#EXTINF:-1,%s\n" %unicodestr)
#        f.write("%s\n" %link)

	hashCode = hashlib.md5(unicodestr).hexdigest()
	#htvList.append({"url": link, "image": "", "name": unicodestr})
	htvList.append({"url": link, "image": img, "name": unicodestr.decode("utf-8"), "hashcode": hashCode})
	
#	f2.write("#EXTINF:-1 tvg-logo=\"%s\"," %img)
#	f2.write("%s\n" %unicodestr)
#	htvLink = "http://hplus.vn//" + hashCode
#        f2.write("%s\n" %htvLink )
#    f.close()
#    f2.close()
    
    #print htvList
    common.SaveList(htvListFile, htvList)



def getContent(url, requestdata):
    req = urllib2 . Request(urllib . unquote_plus(url))
    req.add_header('Content-Type', 'application/x-www-form-urlencoded')
    req.add_header('Authorization', 'Basic YXBpaGF5aGF5dHY6NDUlJDY2N0Bk')
    req.add_header('User-Agent', 'Apache-HttpClient/UNAVAILABLE (java 1.4)')
    link = urllib . urlencode({'request': requestdata})
    resp = urllib2 . urlopen(req, link, 120)
    content = resp . read()
    resp . close()
    content = '' . join(content . splitlines())
    data = json . loads(content)
    return data


	
def Categories():
	#repoCheck.UpdateRepo()

	
	list = common.ReadList(playlistsFile)
	for item in list:
		mode = 1 if item["url"].find(".plx") > 0 else 2
		name = common.GetEncodeString(item["name"])
		AddDir("[COLOR blue]{0}[/COLOR]".format(name) ,item["url"], mode, "")


	#m3uCategory("http://pastebin.com/raw/5jD95hiy")
	AddDir("[COLOR blue]{0}[/COLOR]".format("Local Media"),"library://video/files.xml/", 4, "")
	m3uCategory("http://pastebin.com/raw/G2207ZKh")
	#AddDir("[COLOR white][B]{0}[/B][/COLOR]".format(localizedString(10003).encode('utf-8')), "favorites" ,30 ,os.path.join(addonDir, "resources", "images", "bright_yellow_star.png"))
	#AddDir("[COLOR blue]{0}[/COLOR]".format("US - UK"),"http://pastebin.com/raw.php?i=csh2HJi2", 4, "")
	#AddDir("[COLOR blue]{0}[/COLOR]".format("Vietnam"),"http://pastebin.com/raw.php?i=x7iMAwhF", 4, "")
	#AddDir("[COLOR blue]{0}[/COLOR]".format("Vietnam(from hplus.vn)"),"http://pastebin.com/raw.php?i=mh93beYk" , 4, os.path.join(addonDir, "resources", "images", "hplus.png"))
	#AddDir("[COLOR blue]{0}[/COLOR]".format("Vietnam(fptplay.vn)"),"http://pastebin.com/raw.php?i=mTdWEhjD", 4,  os.path.join(addonDir, "resources", "images", "fpt.png"))
	#AddDir("[COLOR blue]{0}[/COLOR]".format("Vietnam(vtvplus.vn)"),"http://pastebin.com/raw.php?i=PrJcL7zS", 4, os.path.join(addonDir, "resources", "images", "vtv.jpg"))
	#AddDir("[COLOR blue]{0}[/COLOR]".format("Vietnam(sctv.vn)"),"http://pastebin.com/raw.php?i=FisAccqK", 4, os.path.join(addonDir, "resources", "images", "sctv.jpg"))
	#addShowDir("[COLOR blue]{0}[/COLOR]".format("Phim lẻ(Movie)"),"http://pastebin.com/raw.php?i=3vVGkuHa",50,"http://icons.iconarchive.com/icons/hadezign/hobbies/256/Movies-icon.png")
	#AddDir("[COLOR blue]{0}[/COLOR]".format("Phim bộ"),"http://pastebin.com/raw.php?i=qx9AjC1a", 4, "")
	#addShowDir("[COLOR blue]{0}[/COLOR]".format("Music Video"),"http://pastebin.com/raw.php?i=5jD95hiy",4,"http://www.apkdad.com/wp-content/uploads/2012/10/Meridian-Media-Player-Revolute-Icon.png")
	#AddDir("[COLOR blue]{0}[/COLOR]".format("Phóng sự"), "http://pastebin.com/raw.php?i=LR4ZevKu" ,4 ,os.path.join(addonDir, "resources", "images", "phongsu.jpg"))
	#AddDir("[COLOR blue]{0}[/COLOR]".format("Nấu Ăn(Cooking)"), "http://pastebin.com/raw.php?i=82xMAsT0" ,4 ,"https://i.ytimg.com/vi/JW6MO6UAxA8/mqdefault.jpg")

	
	AddDir("[COLOR yellow][B]{0}[/B][/COLOR]".format(localizedString(10001).encode('utf-8')), "settings" , 20, os.path.join(addonDir, "resources", "images", "NewList.ico"), isFolder=False)
	AddDir("[COLOR red][B]{0}[/B][/COLOR]".format("Shutdown"), "Shutdown" ,99 ,os.path.join(addonDir, "resources", "images", "shutdown.png"), isFolder=False)
	if isRasp:
		AddDir("[COLOR red][B]{0}[/B][/COLOR]".format("Restart"), "Restart" ,98 ,os.path.join(addonDir, "resources", "images", "restart.png"), isFolder=False)

def AddNewList():
	listName = GetKeyboardText(localizedString(10004).encode('utf-8')).strip()
	if len(listName) < 1:
		return

	method = GetSourceLocation(localizedString(10002).encode('utf-8'), [localizedString(10016).encode('utf-8'), localizedString(10017).encode('utf-8')])	
	#print method
	if method == -1:
		return
	elif method == 0:
		listUrl = GetKeyboardText(localizedString(10005).encode('utf-8')).strip()
	else:
		listUrl = xbmcgui.Dialog().browse(int(1), localizedString(10006).encode('utf-8'), 'myprograms','.plx|.m3u').decode("utf-8")
		if not listUrl:
			return
	
	if len(listUrl) < 1:
		return


	list = common.ReadList(playlistsFile)
	for item in list:
		if item["url"].lower() == listUrl.lower():

			xbmc.executebuiltin('Notification({0}, "{1}" {2}, 5000, {3})'.format(AddonName, listName, localizedString(10007).encode('utf-8'), icon))
			return
	list.append({"name": listName.decode("utf-8"), "url": listUrl})
	if common.SaveList(playlistsFile, list):
		#xbmc.executebuiltin("XBMC.Container.Update('plugin://{0}')".format(AddonID))
		xbmc.executebuiltin("XBMC.Container.Refresh()")
	
	
def RemoveFromLists(url):
	list = common.ReadList(playlistsFile)
	for item in list:
		if item["url"].lower() == url.lower():
			list.remove(item)
			if common.SaveList(playlistsFile, list):
				xbmc.executebuiltin("XBMC.Container.Refresh()")
			break
			
def PlxCategory(url):
	tmpList = []
	list = common.plx2list(url)
	background = list[0]["background"]
	for channel in list[1:]:
		iconimage = "" if not channel.has_key("thumb") else common.GetEncodeString(channel["thumb"])
		name = common.GetEncodeString(channel["name"])
		if channel["type"] == 'playlist':
			AddDir("[COLOR blue][{0}][/COLOR]".format(name) ,channel["url"], 1, iconimage, background=background)
		else:
			AddDir(name, channel["url"], 3, iconimage, isFolder=False, background=background)
			tmpList.append({"url": channel["url"], "image": iconimage, "name": name.decode("utf-8")})
			
	common.SaveList(tmpListFile, tmpList)
			
def m3uCategory(url):	
	tmpList = []
	list = common.m3u2list(url)

	for channel in list:
		menu = channel["menu"]
		name = common.GetEncodeString(channel["display_name"])
		if "MENU_M3U" in menu:
			AddDir(name,channel["url"], 4, channel["logo"])
		elif  "MENU_XML" in menu:
			addShowDir(name,channel["url"], 50, channel["logo"])
		else:
			AddDir(name ,channel["url"], 3, channel["logo"], isFolder=False)
			tmpList.append({"url": channel["url"], "image": channel["logo"], "name": name.decode("utf-8"), "hashcode": hashlib.md5(name).hexdigest()})

	common.SaveList(tmpListFile, tmpList)
		
def PlayUrl(name, url, iconimage=None):
	print '--- Playing "{0}". {1}'.format(name, url)

	if url.find("viettv") > 0 :
		vIndex = url.index("//",7)
		vIndex = vIndex + 2
		titleName = url[vIndex :]


		vLink = "http://www.viettv24.com/main/getStreamingServerWeb.php"
		vFile = urllib.urlopen(vLink )
		resp = vFile.read()
		data = json.loads(resp)
		url = data[0]['streamApp'] + titleName +  "/playlist.m3u8?" + data[0]['key']

	elif url.find("fptplay.vn") > 0 :
		vIndex = url.index("//",7)
		vIndex = vIndex + 2
		id = url[vIndex :]


		myurl = 'http://fptplay.net/show/getlinklivetv'
		headers=	{
					'User-Agent':'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:39.0) Gecko/20100101 Firefox/39.0',
					'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
					'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
					'X-Requested-With': 'XMLHttpRequest',
					'Referer': 'http://fptplay.net/livetv'
					}
		params = {"id": id,"type": "newchannel",
				   "quality": __settings__.getSetting('quality'),"mobile": "web"}
		mydata = urllib.urlencode(params)

		myreq= urllib2.Request(myurl, mydata, headers)
		result = urllib2.urlopen(myreq)

		if result.code != 200 :
			url = None
		else :
			info = json.loads(result.read() )
			url = info['stream']
	elif url.find("thvl.vn") > 0 :
		url = getTHVL(url)
	elif url.find("xemtvhd.com/stream-newtv") > 0 :
		url = getXemTvHd(url)
	elif url.find("hplus.vn") > 0 :
		vIndex = url.index("//",7)
		vIndex = vIndex + 2
		hashcode = url[vIndex :]

		htvList = common.ReadList(htvListFile)	
		for item in htvList:
	
			if hashcode  ==  item["hashcode"]:
				url = item["url"]
				break		
	elif 'htvonline' in url:
		content = Get_Url(url)	
		url = re.compile('data\-source=\"([^\"]*)\"').findall(content)[0]
	elif 'stream.anluong' in url:
		content = Get_Url(url)	
		url = re.compile('mf\.php\?u=([^\']*)\'').findall(content)[0]
	elif 'm.xemtvhd.com' in url:
		content = Get_Url(url)	
		print "==Viet ", content
		url = re.compile('stream\s*=\s*\"([^\"]*)\"').findall(content)[0]
		print "==url ", url
	elif 'hplus.com' in url:
		url = getHTV(url)
	elif 'tv24.vn' in url:
		url = getSCTVWithCookie(url)
	elif 'shutdown' in url:
		xbmc.executebuiltin("System.Exec(/usr/bin/turnoff.sh)")
		sys.exit()
	elif 'restart' in url:
		xbmc.executebuiltin("System.Exec(/usr/bin/restart.sh)")
		sys.exit()

	listitem = xbmcgui.ListItem(path=url, thumbnailImage=iconimage)
	listitem.setInfo(type="Video", infoLabels={ "Title": name })
	xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, listitem)
	
	
	

	

def AddDir(name, url, mode, iconimage, description="", isFolder=True, background=None):
	u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&description="+urllib.quote_plus(description)

	liz = xbmcgui.ListItem(name, iconImage=iconimage, thumbnailImage=iconimage)
	liz.setInfo(type="Video", infoLabels={ "Title": name, "Plot": description})
	if background:
		liz.setProperty('fanart_image', background)
	if mode == 1 or mode == 2:
		liz.addContextMenuItems(items = [('{0}'.format(localizedString(10008).encode('utf-8')), 'XBMC.RunPlugin({0}?url={1}&mode=22)'.format(sys.argv[0], urllib.quote_plus(url)))])
	elif mode == 3:
		liz.setProperty('IsPlayable', 'true')
		liz.addContextMenuItems(items = [('{0}'.format(localizedString(10009).encode('utf-8')), 'XBMC.RunPlugin({0}?url={1}&mode=31&iconimage={2}&name={3})'.format(sys.argv[0], urllib.quote_plus(url), iconimage, name))])
	elif mode == 4:
		liz.setProperty('IsPlayable', 'true')
	elif mode == 32:
		liz.setProperty('IsPlayable', 'true')
		liz.addContextMenuItems(items = [('{0}'.format(localizedString(10010).encode('utf-8')), 'XBMC.RunPlugin({0}?url={1}&mode=33&iconimage={2}&name={3})'.format(sys.argv[0], urllib.quote_plus(url), iconimage, name))])
		
	if ('plugin://plugin.video.zeus/?mode=20' in url) or ('library://' in url) or ('plugin.video.youtube/channel/' in url) or ('plugin.video.youtube/user/' in url) \
	     or ('plugin://plugin.video.genesis/' in url) :	
		isFolder = True
		u = url
		
	xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz, isFolder=isFolder)

def GetKeyboardText(title = "", defaultText = ""):
	keyboard = xbmc.Keyboard(defaultText, title)
	keyboard.doModal()
	text =  "" if not keyboard.isConfirmed() else keyboard.getText()
	return text

def GetSourceLocation(title, list):
	dialog = xbmcgui.Dialog()
	answer = dialog.select(title, list)
	return answer
	

def AddFavorites2(url, iconimage, name):

	favList = common.ReadList(favoritesFile)
	#use url find hash code, url = http://hplus.vn//hashcode
	#for item in favList:
	#	if item["url"].lower() == url.lower():
	#		xbmc.executebuiltin("Notification({0}, '{1}' {2}, 5000, {3})".format(AddonName, name, localizedString(10011).encode('utf-8'), icon))
	#		return
    
	list = common.ReadList(tmpListFile)	
	
	for channel in list:
		if channel["url"].lower() == url.lower():
			url = channel["url"]	
			iconimage = channel["image"]
			if url.find("cdnviet.com") > 0 :
				url = "http://hplus.vn//" + channel["hashcode"]
			break
			
	if not iconimage:
		iconimage = ""
		
	data = {"url": url, "image": iconimage, "name": name.decode("utf-8")}
	
	favList.append(data)

	common.SaveList(favoritesFile, favList)
	xbmc.executebuiltin("Notification({0}, '{1}' {2}, 5000, {3})".format(AddonName, name, localizedString(10012).encode('utf-8'), icon))


def AddFavorites(url, iconimage, name):
	favList = common.ReadList(favoritesFile)
	for item in favList:
		if item["url"].lower() == url.lower():
			xbmc.executebuiltin("Notification({0}, '{1}' {2}, 5000, {3})".format(AddonName, name, localizedString(10011).encode('utf-8'), icon))
			return
    
	list = common.ReadList(tmpListFile)	

			
	if not iconimage:
		iconimage = ""
		
	data = {"url": url, "image": iconimage, "name": name.decode("utf-8")}
	
	favList.append(data)
	common.SaveList(favoritesFile, favList)
	xbmc.executebuiltin("Notification({0}, '{1}' {2}, 5000, {3})".format(AddonName, name, localizedString(10012).encode('utf-8'), icon))
	
def ListFavorites():
	#AddDir("[COLOR yellow][B]{0}[/B][/COLOR]".format(localizedString(10013).encode('utf-8')), "favorites" ,34 ,os.path.join(addonDir, "resources", "images", "bright_yellow_star.png"), isFolder=False)
	list = common.ReadList(favoritesFile)
	for channel in list:
		name = channel["name"].encode("utf-8")
		iconimage = channel["image"].encode("utf-8")
		AddDir(name, channel["url"], 32, iconimage, isFolder=False) 
		
def RemoveFavorties(url):
	list = common.ReadList(favoritesFile) 
	for channel in list:
		if channel["url"].lower() == url.lower():
			list.remove(channel)
			break
			
	common.SaveList(favoritesFile, list)
	xbmc.executebuiltin("XBMC.Container.Refresh()")
	
def AddNewFavortie():
	chName = GetKeyboardText("{0}".format(localizedString(10014).encode('utf-8'))).strip()
	if len(chName) < 1:
		return
	chUrl = GetKeyboardText("{0}".format(localizedString(10015).encode('utf-8'))).strip()
	if len(chUrl) < 1:
		return
		
	favList = common.ReadList(favoritesFile)
	for item in favList:
		if item["url"].lower() == url.lower():
			xbmc.executebuiltin("Notification({0}, '{1}' {2}, 5000, {3})".format(AddonName, chName, localizedString(10011).encode('utf-8'), icon))
			return
			
	data = {"url": chUrl, "image": "", "name": chName.decode("utf-8")}
	
	favList.append(data)
	if common.SaveList(favoritesFile, favList):
		xbmc.executebuiltin("XBMC.Container.Update('plugin://{0}?mode=30&url=favorites')".format(AddonID))






def TVChannel(url):
    xmlcontent = GetUrl(url)

    names = re.compile('<name>(.+?)</name>\s*<thumbnail>(.+?)</thumbnail>').findall(xmlcontent)
    #names = re.compile('<name>(.+?)</name>').findall(xmlcontent)
    #thumbMenu = re.compile('<thumbnail>(.+?)</thumbnail>').findall(xmlcontent)
    if len(names) == 1:
        items = re.compile('<item>(.+?)</item>').findall(xmlcontent)
        for item in items:
            thumb=""
            title=""
            link=""
            if "/title" in item:
                title = re.compile('<title>(.+?)</title>').findall(item)[0]
            if "/link" in item:
                link = re.compile('<link>(.+?)</link>').findall(item)[0]
            if "/thumbnail" in item:
                thumb = re.compile('<thumbnail>(.+?)</thumbnail>').findall(item)[0]
            add_Link(title, link, thumb)	
    else:
	imgIndex = 0
        for name,thumb in names:
            addShowDir('' + name + '', url+"?n="+name, 52, thumb)
	

def IndexMenu(url,iconimage):
    byname = url.split("?n=")[1]
    url = url.split("?n")[0]
    xmlcontent = GetUrl(url)
    channels = re.compile('<channel>(.+?)</channel>').findall(xmlcontent)
    for channel in channels:
        if byname in channel:
            items = re.compile('<item>(.+?)</item>').findall(channel)
            for item in items:
                thumb=""
                title=""
                link=""
                if "/title" in item:
                    title = re.compile('<title>(.+?)</title>').findall(item)[0]
                if "/link" in item:
                    link = re.compile('<link>(.+?)</link>').findall(item)[0]
                if "/thumbnail" in item:
                    thumb = re.compile('<thumbnail>(.+?)</thumbnail>').findall(item)[0]	
                add_Link(title, link, thumb)				
                #addLink('' + title + '', link, 'play', thumb)

	
def resolveUrl(url):
	if 'xemphimso' in url:
		content = Get_Url(url)	
		url = urllib.unquote_plus(re.compile("file=(.+?)&").findall(content)[0])
	elif 'vtvplay' in url:
		content = Get_Url(url)
		url = content.replace("\"", "")
		url = url[:-5]
	elif 'vtvplus' in url:
		content = Get_Url(url)
		url = re.compile('var responseText = "(.+?)";').findall(content)[0]		
	elif 'htvonline' in url:
		content = Get_Url(url)	
		url = re.compile('data\-source=\"([^\"]*)\"').findall(content)[0]
	elif 'hplus' in url:
		content = Get_Url(url)	
		url = re.compile('iosUrl = "(.+?)";').findall(content)[0]		
	else:
		url = url
	item=xbmcgui.ListItem(path=url)
	xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)	  
	return

    
def GetUrl(url):
    link = ""
    if os.path.exists(url)==True:
        link = open(url).read()
    else:
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 6.2; WOW64; Trident/6.0)')
        response = urllib2.urlopen(req)
        link=response.read()
        response.close()
    link = ''.join(link.splitlines()).replace('\'','"')
    link = link.replace('\n','')
    link = link.replace('\t','')
    link = re.sub('  +',' ',link)
    link = link.replace('> <','><')
    return link
	
def add_Link(name,url,iconimage):
    u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode=51"  
    liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
    liz.setInfo( type="Video", infoLabels={ "Title": name } )
    liz.setProperty('IsPlayable', 'true')  
    isDir = False

    if ('www.youtube.com/user/' in url) or ('www.youtube.com/channel/' in url):
        u = 'plugin://plugin.video.youtube/%s/%s/' % (url.split( '/' )[-2], url.split( '/' )[-1])	
        isDir = True
    elif ('plugin.video.youtube/channel/' in url) or ('plugin.video.youtube/user/' in url) \
	      or ('plugin://plugin.video.genesis/' in url):	
        u = url
        isDir = True

    ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=isDir)  


def addShowDir(name,url,mode,iconimage):
    u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
    ok=True
    liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
    liz.setInfo( type="Video", infoLabels={ "Title": name } )
    ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
    return ok	
	




def Get_Url(url):
    try:
		req=urllib2.Request(url)
		req.add_header('User-Agent', 'Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 6.2; WOW64; Trident/6.0)')
		response=urllib2.urlopen(req)
		link=response.read()

		#headers = response.info()
		#print "The Headers are: ", headers 
		
		response.close()  
		return link
    except:
		pass


def get_params():
	param = []
	paramstring = sys.argv[2]
	if len(paramstring) >= 2:
		params = sys.argv[2]
		cleanedparams = params.replace('?','')
		if (params[len(params)-1] == '/'):
			params = params[0:len(params)-2]
		pairsofparams = cleanedparams.split('&')
		param = {}
		for i in range(len(pairsofparams)):
			splitparams = {}
			splitparams = pairsofparams[i].split('=')
			if (len(splitparams)) == 2:
				param[splitparams[0].lower()] = splitparams[1]
	return param


params=get_params()
url=None
name=None
mode=None
iconimage=None
description=None

try:
	url = urllib.unquote_plus(params["url"])
except:
	pass
try:
	name = urllib.unquote_plus(params["name"])
except:
	pass
try:
	iconimage = urllib.unquote_plus(params["iconimage"])
except:
	pass
try:        
	#mode = int(params["mode"])
	mode = params["mode"]
except:
	pass
try:       
	description = urllib.unquote_plus(params["description"])
except:
	pass

	
if mode == None or url == None or len(url) < 1:
	#home()
	#getChannels()
	Categories()
elif mode == '1':
	PlxCategory(url)
elif mode == '2' or mode == '4':
	m3uCategory(url)
elif mode == '3' or mode == '32':
	PlayUrl(name, url, iconimage)
elif mode == '20':
	AddNewList()
elif mode == '22':
	RemoveFromLists(url)
elif mode == '30':
	ListFavorites()
elif mode == '31': 
	AddFavorites(url, iconimage, name) 
elif mode == '33':
	RemoveFavorties(url)
elif mode == '34':
	AddNewFavortie()
elif mode == '98':
	if isRasp:
		xbmc.executebuiltin("System.Exec(/usr/bin/restart.sh)")
	else:
		xbmc.executebuiltin("XBMC.Reboot()")
	sys.exit()
elif mode == '99':
	if isRasp:
		xbmc.executebuiltin("System.Exec(/usr/bin/turnoff.sh)")
	else:
		xbmc.executebuiltin("XBMC.Quit()")
	sys.exit()
elif mode == '40':
	common.DelFile(playlistsFile)
	sys.exit()
elif mode == '41':
	common.DelFile(favoritesFile)
	sys.exit()
elif mode == '50':
	TVChannel(url)	
elif mode=='51':
	PlayUrl(name, url, iconimage)
	#resolveUrl(url)
elif mode=='52':
	IndexMenu(url,iconimage)


xbmcplugin.endOfDirectory(int(sys.argv[1]))
